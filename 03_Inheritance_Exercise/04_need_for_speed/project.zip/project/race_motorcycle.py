from project.motorcycle import Motorcycle
from project.vehicle import Vehicle


class RaceMotorcycle(Motorcycle, Vehicle):
    DEFAULT_FUEL_CONSUMPTION = 8
