from project.car import Car
from project.vehicle import Vehicle


class FamilyCar(Car, Vehicle):
   pass
