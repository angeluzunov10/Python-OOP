from project.car import Car
from project.vehicle import Vehicle


class SportCar(Car, Vehicle):
    DEFAULT_FUEL_CONSUMPTION = 10
