from project.motorcycle import Motorcycle
from project.vehicle import Vehicle


class CrossMotorcycle(Motorcycle, Vehicle):
    pass
