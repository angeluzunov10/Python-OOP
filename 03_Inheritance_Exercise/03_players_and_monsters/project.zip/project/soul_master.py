from project.dark_wizard import DarkWizard
from project.hero import Hero
from project.wizard import Wizard


class SoulMaster(DarkWizard, Wizard, Hero):
    pass