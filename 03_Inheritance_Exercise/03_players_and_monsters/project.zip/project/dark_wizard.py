from project.hero import Hero
from project.wizard import Wizard


class DarkWizard(Wizard, Hero):
    pass
