from project.elf import Elf
from project.hero import Hero


class MuseElf(Elf, Hero):
    pass
