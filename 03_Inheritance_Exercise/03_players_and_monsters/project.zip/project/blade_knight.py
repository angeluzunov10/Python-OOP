from project.dark_knight import DarkKnight
from project.hero import Hero
from project.knight import Knight


class BladeKnight(DarkKnight, Knight, Hero):
    pass
