from project.hero import Hero
from project.knight import Knight


class DarkKnight(Knight, Hero):
    pass
